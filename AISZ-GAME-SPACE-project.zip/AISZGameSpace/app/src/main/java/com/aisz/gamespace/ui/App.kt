package com.aisz.gamespace.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Create
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.sp
import com.aisz.gamespace.MainActivity
import com.aisz.gamespace.TouchTesterScreen

enum class Tab(val label: String, val icon: ImageVector) {
    DASHBOARD("Beranda", Icons.Filled.Home),
    GAMES("Game", Icons.Filled.PlayArrow),
    MONITOR("Monitor", Icons.Filled.Info),
    TOUCH("Sentuh", Icons.Filled.Create),
    SETTINGS("Atur", Icons.Filled.Settings)
}

@Composable
fun AiszApp(activity: MainActivity) {
    var tab by remember { mutableStateOf(Tab.DASHBOARD) }

    Scaffold(
        containerColor = AiszColors.Black,
        bottomBar = {
            NavigationBar(containerColor = AiszColors.Surface) {
                Tab.values().forEach { t ->
                    NavigationBarItem(
                        selected = tab == t,
                        onClick = { tab = t },
                        icon = { Icon(t.icon, contentDescription = t.label) },
                        label = { Text(t.label, fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = AiszColors.Neon,
                            selectedTextColor = AiszColors.Neon,
                            unselectedIconColor = AiszColors.TextDim,
                            unselectedTextColor = AiszColors.TextDim,
                            indicatorColor = AiszColors.Neon.copy(alpha = 0.18f)
                        )
                    )
                }
            }
        }
    ) { padding ->
        AnimatedContent(
            targetState = tab,
            modifier = Modifier.padding(padding).background(AiszColors.Black),
            transitionSpec = { fadeIn(tween(250)) togetherWith fadeOut(tween(150)) },
            label = "tab"
        ) { current ->
            when (current) {
                Tab.DASHBOARD -> DashboardScreen(activity) { tab = Tab.GAMES }
                Tab.GAMES -> GamesScreen(activity)
                Tab.MONITOR -> MonitorScreen()
                Tab.TOUCH -> TouchTesterScreen()
                Tab.SETTINGS -> SettingsScreen(activity)
            }
        }
    }
}
