package com.aisz.gamespace

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import kotlin.math.abs
import kotlin.math.max

/**
 * Panel gaming melayang: handle tipis di tepi layar. Ketuk = buka/tutup,
 * seret = pindahkan (otomatis menempel ke tepi kiri/kanan).
 * Memakai SYSTEM_ALERT_WINDOW (TYPE_APPLICATION_OVERLAY), tanpa root.
 */
class FloatingPanelService : Service() {

    private lateinit var wm: WindowManager
    private lateinit var params: WindowManager.LayoutParams
    private var root: LinearLayout? = null
    private lateinit var handle: FrameLayout
    private lateinit var panel: LinearLayout
    private lateinit var tvTemp: TextView
    private lateinit var tvRam: TextView
    private lateinit var gamesBox: LinearLayout

    private var expanded = false
    private var dockRight = false
    private val handler = Handler(Looper.getMainLooper())

    private val ticker = object : Runnable {
        override fun run() {
            refreshStats()
            handler.postDelayed(this, 2000L)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startAsForeground()
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Izin tampil di atas aplikasi lain belum diberikan.", Toast.LENGTH_LONG).show()
            stopSelf()
            return START_NOT_STICKY
        }
        if (root == null) buildOverlay()
        isRunning = true
        handler.removeCallbacks(ticker)
        handler.post(ticker)
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        root?.let {
            try {
                wm.removeView(it)
            } catch (_: Exception) {
            }
        }
        root = null
        isRunning = false
        super.onDestroy()
    }

    // ------------------------------------------------------------------ notifikasi

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(CHANNEL_ID, "Panel gaming", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, FloatingPanelService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_aisz)
            .setContentTitle("AISZ GAME SPACE")
            .setContentText("Panel gaming aktif")
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(open)
            .addAction(0, "Tutup panel", stop)
            .build()
    }

    private fun startAsForeground() {
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    // ------------------------------------------------------------------ overlay

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun rounded(fill: Int, radius: Float, stroke: Int? = null): GradientDrawable =
        GradientDrawable().apply {
            setColor(fill)
            cornerRadius = radius
            if (stroke != null) setStroke(dp(1), stroke)
        }

    private fun label(text: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        }

    private fun button(text: String, onClick: () -> Unit): TextView =
        TextView(this).apply {
            this.text = text
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(TEXT)
            setPadding(dp(6), dp(8), dp(6), dp(8))
            background = rounded(SURFACE_HIGH, dp(10).toFloat(), NEON)
            setOnClickListener { onClick() }
        }

    private fun row(vararg views: View): LinearLayout =
        LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            views.forEach {
                addView(it, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                    setMargins(dp(2), dp(3), dp(2), dp(3))
                })
            }
        }

    private fun audio() = getSystemService(Context.AUDIO_SERVICE) as AudioManager

    private fun adjustVolume(direction: Int) {
        try {
            audio().adjustStreamVolume(AudioManager.STREAM_MUSIC, direction, AudioManager.FLAG_SHOW_UI)
        } catch (e: SecurityException) {
            Toast.makeText(this, "Tidak dapat mengubah volume.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun buildPanel(): LinearLayout {
        val p = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = rounded(PANEL_BG, dp(16).toFloat(), NEON)
        }
        p.addView(label("AISZ GAME SPACE", 13f, NEON, true))
        tvTemp = label("Suhu: --", 12f, TEXT)
        tvRam = label("RAM: --", 12f, TEXT)
        p.addView(tvTemp)
        p.addView(tvRam)
        p.addView(label("FPS game: N/A", 12f, TEXT_DIM))

        p.addView(row(
            button("Vol +") { adjustVolume(AudioManager.ADJUST_RAISE) },
            button("Vol -") { adjustVolume(AudioManager.ADJUST_LOWER) },
            button("Mute") { adjustVolume(AudioManager.ADJUST_TOGGLE_MUTE) }
        ))

        p.addView(label("Game favorit", 11f, TEXT_DIM))
        gamesBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        p.addView(gamesBox)

        p.addView(row(
            button("Buka AISZ") { openApp() },
            button("Tutup") { stopSelf() }
        ))
        return p
    }

    private fun openApp() {
        val i = Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
        startActivity(i)
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun buildOverlay() {
        val bar = View(this).apply { background = rounded(NEON, dp(3).toFloat()) }
        handle = FrameLayout(this).apply {
            addView(bar, FrameLayout.LayoutParams(dp(6), dp(72), Gravity.CENTER))
            setOnTouchListener(dragListener)
        }
        panel = buildPanel()
        panel.visibility = View.GONE

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        root = container
        arrangeChildren()

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }
        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = resources.displayMetrics.heightPixels / 3
        }
        wm.addView(container, params)
    }

    private fun arrangeChildren() {
        val r = root ?: return
        r.removeAllViews()
        val handleLp = LinearLayout.LayoutParams(dp(22), dp(96))
        val panelLp = LinearLayout.LayoutParams(dp(210), LinearLayout.LayoutParams.WRAP_CONTENT)
        if (dockRight) {
            r.addView(panel, panelLp)
            r.addView(handle, handleLp)
        } else {
            r.addView(handle, handleLp)
            r.addView(panel, panelLp)
        }
    }

    private fun updateLayout() {
        val r = root ?: return
        val dm = resources.displayMetrics
        params.x = params.x.coerceIn(0, max(0, dm.widthPixels - r.width))
        params.y = params.y.coerceIn(0, max(0, dm.heightPixels - r.height))
        try {
            wm.updateViewLayout(r, params)
        } catch (_: Exception) {
        }
    }

    private fun stickToEdge() {
        val r = root ?: return
        val dm = resources.displayMetrics
        params.x = if (dockRight) dm.widthPixels - r.width else 0
        updateLayout()
    }

    private fun toggle() {
        expanded = !expanded
        panel.visibility = if (expanded) View.VISIBLE else View.GONE
        if (expanded) {
            refreshFavorites()
            refreshStats()
        }
        root?.post { stickToEdge() }
    }

    private val dragListener = object : View.OnTouchListener {
        private var startRawX = 0f
        private var startRawY = 0f
        private var startX = 0
        private var startY = 0
        private var dragging = false
        private val slop by lazy { ViewConfiguration.get(this@FloatingPanelService).scaledTouchSlop }

        override fun onTouch(v: View, e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startRawX = e.rawX
                    startRawY = e.rawY
                    startX = params.x
                    startY = params.y
                    dragging = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - startRawX
                    val dy = e.rawY - startRawY
                    if (!dragging && (abs(dx) > slop || abs(dy) > slop)) dragging = true
                    if (dragging) {
                        params.x = (startX + dx).toInt()
                        params.y = (startY + dy).toInt()
                        updateLayout()
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (dragging) {
                        val r = root
                        if (r != null) {
                            val centerX = params.x + r.width / 2
                            val right = centerX > resources.displayMetrics.widthPixels / 2
                            if (right != dockRight) {
                                dockRight = right
                                arrangeChildren()
                            }
                            r.post { stickToEdge() }
                        }
                    } else {
                        v.performClick()
                        toggle()
                    }
                }
            }
            return true
        }
    }

    // ------------------------------------------------------------------ data

    private fun refreshStats() {
        if (root == null) return
        val t = TemperatureMonitor(this).read()
        tvTemp.text = "Suhu: ${formatCelsius(t.batteryC)} (${t.level.label})"
        val m = PerformanceMonitor(this).memory()
        tvRam.text = "RAM bebas: ${m.availMb} MB (${100 - m.usedPercent}%)"
    }

    private fun refreshFavorites() {
        gamesBox.removeAllViews()
        val launcher = GameLauncher(this)
        val favs = launcher.loadGames(withIcons = false).filter { it.isFavorite }.take(4)
        if (favs.isEmpty()) {
            gamesBox.addView(label("Belum ada favorit", 11f, TEXT))
            return
        }
        favs.forEach { g ->
            val b = button(g.label) {
                if (!launcher.launch(g.packageName)) {
                    Toast.makeText(this, "Tidak dapat membuka ${g.label}", Toast.LENGTH_SHORT).show()
                } else if (expanded) {
                    toggle()
                }
            }
            gamesBox.addView(b, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { setMargins(0, dp(3), 0, dp(3)) })
        }
    }

    companion object {
        const val ACTION_STOP = "com.aisz.gamespace.action.STOP_PANEL"
        private const val CHANNEL_ID = "aisz_panel"
        private const val NOTIF_ID = 1001

        private val NEON = Color.parseColor("#00B7FF")
        private val TEXT = Color.parseColor("#E6F4FF")
        private val TEXT_DIM = Color.parseColor("#8AA4BF")
        private val SURFACE_HIGH = Color.parseColor("#111B30")
        private val PANEL_BG = Color.parseColor("#F00B1220")

        @Volatile
        var isRunning: Boolean = false
            private set

        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, FloatingPanelService::class.java))
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, FloatingPanelService::class.java))
        }
    }
}
