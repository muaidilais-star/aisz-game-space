package com.aisz.gamespace.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.aisz.gamespace.FloatingPanelService
import com.aisz.gamespace.FpsMonitor
import com.aisz.gamespace.GameInfo
import com.aisz.gamespace.GameLauncher
import com.aisz.gamespace.GameSettings
import com.aisz.gamespace.GamingProfile
import com.aisz.gamespace.MainActivity
import com.aisz.gamespace.OrientationMode
import com.aisz.gamespace.PerformanceMonitor
import com.aisz.gamespace.TempLevel
import com.aisz.gamespace.TemperatureMonitor
import com.aisz.gamespace.formatCelsius
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

private fun levelColor(level: TempLevel): Color = when (level) {
    TempLevel.NORMAL -> AiszColors.Ok
    TempLevel.WARM -> AiszColors.Warn
    TempLevel.HIGH -> AiszColors.Hot
    TempLevel.UNKNOWN -> AiszColors.TextDim
}

@Composable
private fun ScreenTitle(title: String, subtitle: String? = null) {
    Text(title, color = AiszColors.Neon, fontSize = 22.sp, fontWeight = FontWeight.Bold)
    if (subtitle != null) Text(subtitle, color = AiszColors.TextDim, fontSize = 13.sp)
}

// =============================================================== DASHBOARD

@Composable
fun DashboardScreen(activity: MainActivity, onStartGaming: () -> Unit) {
    val ctx = LocalContext.current
    val perf = remember { PerformanceMonitor(ctx) }
    val thermalMonitor = remember { TemperatureMonitor(ctx) }
    val launcher = remember { GameLauncher(ctx) }
    val device = remember { perf.deviceInfo() }
    var memory by remember { mutableStateOf(perf.memory()) }
    var battery by remember { mutableStateOf(perf.battery()) }
    var thermal by remember { mutableStateOf(thermalMonitor.read()) }
    var gameCount by remember { mutableStateOf(0) }
    var panelOn by remember { mutableStateOf(FloatingPanelService.isRunning) }
    var showPermDialog by remember { mutableStateOf(false) }
    val tick = activity.resumeTick.value

    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    LaunchedEffect(tick) {
        gameCount = withContext(Dispatchers.IO) { launcher.loadGames(withIcons = false).size }
    }
    LaunchedEffect(Unit) {
        while (true) {
            memory = perf.memory()
            battery = perf.battery()
            thermal = thermalMonitor.read()
            panelOn = FloatingPanelService.isRunning
            delay(2000)
        }
    }

    fun enablePanel(): Boolean {
        if (!Settings.canDrawOverlays(ctx)) {
            showPermDialog = true
            return false
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        FloatingPanelService.start(ctx)
        panelOn = true
        return true
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Column(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                "AISZ",
                color = AiszColors.Neon,
                fontSize = 44.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 8.sp,
                style = TextStyle(shadow = Shadow(AiszColors.Neon, Offset.Zero, 32f))
            )
            Text("GAME SPACE", color = AiszColors.Text, fontSize = 16.sp, letterSpacing = 6.sp)
        }

        NeonButton("MULAI GAMING", Modifier.fillMaxWidth()) {
            if (enablePanel()) onStartGaming()
        }

        GlowCard {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Floating Panel", color = AiszColors.Text, fontWeight = FontWeight.Bold)
                    Text(
                        if (panelOn) "Aktif: handle di tepi layar" else "Nonaktif",
                        color = AiszColors.TextDim, fontSize = 12.sp
                    )
                }
                Switch(
                    checked = panelOn,
                    onCheckedChange = { on ->
                        if (on) enablePanel() else {
                            FloatingPanelService.stop(ctx)
                            panelOn = false
                        }
                    },
                    colors = SwitchDefaults.colors(
                        checkedTrackColor = AiszColors.Neon,
                        checkedThumbColor = AiszColors.Black,
                        uncheckedTrackColor = AiszColors.SurfaceHigh,
                        uncheckedThumbColor = AiszColors.TextDim
                    )
                )
            }
        }

        GlowCard {
            SectionTitle("Status sistem")
            StatRow("RAM terpakai", "${memory.usedPercent}% (${memory.availMb} MB bebas)")
            StatRow(
                "Baterai",
                (battery.levelPercent?.let { "$it%" } ?: "N/A") + if (battery.charging) " (mengisi)" else ""
            )
            StatRow("Suhu baterai", formatCelsius(thermal.batteryC))
            StatRow("Kondisi suhu", thermal.level.label, levelColor(thermal.level))
            StatRow("Game terdeteksi", "$gameCount")
        }

        GlowCard {
            SectionTitle("Informasi perangkat")
            StatRow("Perangkat", "${device.manufacturer} ${device.model}")
            StatRow("Android", "${device.androidVersion} (API ${device.apiLevel})")
            StatRow("Layar", device.screen)
            StatRow("Refresh rate", String.format(Locale.US, "%.0f Hz", device.refreshRateHz))
        }
    }

    if (showPermDialog) {
        AlertDialog(
            onDismissRequest = { showPermDialog = false },
            containerColor = AiszColors.Surface,
            titleContentColor = AiszColors.Neon,
            textContentColor = AiszColors.Text,
            title = { Text("Izin tampil di atas aplikasi lain") },
            text = {
                Text(
                    "Floating panel memerlukan izin \"Tampil di atas aplikasi lain\" (SYSTEM_ALERT_WINDOW). " +
                        "Aktifkan untuk AISZ GAME SPACE di pengaturan, lalu kembali ke aplikasi."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    showPermDialog = false
                    ctx.safeStart(
                        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}"))
                    )
                }) { Text("Buka Pengaturan", color = AiszColors.Neon) }
            },
            dismissButton = {
                TextButton(onClick = { showPermDialog = false }) { Text("Batal", color = AiszColors.TextDim) }
            }
        )
    }
}

// =============================================================== GAMES

@Composable
fun GamesScreen(activity: MainActivity) {
    val ctx = LocalContext.current
    val launcher = remember { GameLauncher(ctx) }
    val scope = rememberCoroutineScope()
    var games by remember { mutableStateOf<List<GameInfo>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var reload by remember { mutableStateOf(0) }
    var showAdd by remember { mutableStateOf(false) }
    var addable by remember { mutableStateOf<List<GameInfo>>(emptyList()) }
    val tick = activity.resumeTick.value

    LaunchedEffect(reload, tick) {
        loading = true
        games = withContext(Dispatchers.IO) { launcher.loadGames() }
        loading = false
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { ScreenTitle("Game Launcher", "${games.size} game di daftar") }
            NeonButton("+ Tambah") {
                scope.launch {
                    addable = withContext(Dispatchers.IO) { launcher.loadAddableApps() }
                    showAdd = true
                }
            }
        }
        Spacer(Modifier.height(12.dp))

        when {
            loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = AiszColors.Neon)
            }
            games.isEmpty() -> GlowCard {
                Text(
                    "Belum ada game terdeteksi. Android hanya menandai sebagian aplikasi sebagai game, " +
                        "jadi tekan \"+ Tambah\" untuk memilih game secara manual.",
                    color = AiszColors.TextDim, fontSize = 14.sp
                )
            }
            else -> LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(games, key = { it.packageName }) { g ->
                    GlowCard(contentPadding = 12.dp) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            val icon = g.icon
                            if (icon != null) {
                                Image(
                                    bitmap = icon,
                                    contentDescription = g.label,
                                    modifier = Modifier.size(48.dp).clip(RoundedCornerShape(12.dp))
                                )
                            } else {
                                Box(Modifier.size(48.dp).clip(RoundedCornerShape(12.dp)).background(AiszColors.SurfaceHigh))
                            }
                            Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                                Text(
                                    g.label, color = AiszColors.Text, fontWeight = FontWeight.Bold,
                                    maxLines = 1, overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    g.packageName, color = AiszColors.TextDim, fontSize = 11.sp,
                                    maxLines = 1, overflow = TextOverflow.Ellipsis
                                )
                            }
                            IconButton(onClick = {
                                launcher.toggleFavorite(g.packageName)
                                reload++
                            }) {
                                Icon(
                                    if (g.isFavorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                                    contentDescription = "Favorit",
                                    tint = if (g.isFavorite) AiszColors.Hot else AiszColors.TextDim
                                )
                            }
                            IconButton(onClick = {
                                launcher.removeGame(g.packageName)
                                Toast.makeText(ctx, "${g.label} dihapus dari daftar (aplikasi tidak di-uninstall)", Toast.LENGTH_SHORT).show()
                                reload++
                            }) {
                                Icon(Icons.Filled.Delete, contentDescription = "Hapus dari daftar", tint = AiszColors.TextDim)
                            }
                            IconButton(onClick = {
                                if (!launcher.launch(g.packageName)) {
                                    Toast.makeText(ctx, "Tidak dapat membuka ${g.label}", Toast.LENGTH_SHORT).show()
                                }
                            }) {
                                Icon(Icons.Filled.PlayArrow, contentDescription = "Buka game", tint = AiszColors.Neon)
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAdd) {
        AlertDialog(
            onDismissRequest = { showAdd = false },
            containerColor = AiszColors.Surface,
            titleContentColor = AiszColors.Neon,
            textContentColor = AiszColors.Text,
            title = { Text("Tambah game") },
            text = {
                if (addable.isEmpty()) {
                    Text("Tidak ada aplikasi lain yang bisa ditambahkan.")
                } else {
                    LazyColumn(Modifier.heightIn(max = 420.dp)) {
                        items(addable, key = { it.packageName }) { a ->
                            Row(
                                Modifier.fillMaxWidth()
                                    .clickable {
                                        launcher.addGame(a.packageName)
                                        showAdd = false
                                        reload++
                                    }
                                    .padding(vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                val icon = a.icon
                                if (icon != null) {
                                    Image(
                                        bitmap = icon, contentDescription = null,
                                        modifier = Modifier.size(36.dp).clip(RoundedCornerShape(8.dp))
                                    )
                                }
                                Text(
                                    a.label, color = AiszColors.Text,
                                    modifier = Modifier.padding(start = 12.dp),
                                    maxLines = 1, overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showAdd = false }) { Text("Tutup", color = AiszColors.Neon) }
            }
        )
    }
}

// =============================================================== MONITOR

@Composable
fun MonitorScreen() {
    val ctx = LocalContext.current
    val perf = remember { PerformanceMonitor(ctx) }
    val thermalMonitor = remember { TemperatureMonitor(ctx) }
    val device = remember { perf.deviceInfo() }
    val fpsMonitor = remember { FpsMonitor() }
    var memory by remember { mutableStateOf(perf.memory()) }
    var battery by remember { mutableStateOf(perf.battery()) }
    var thermal by remember { mutableStateOf(thermalMonitor.read()) }

    DisposableEffect(Unit) {
        fpsMonitor.start()
        onDispose { fpsMonitor.stop() }
    }
    LaunchedEffect(Unit) {
        while (true) {
            memory = perf.memory()
            battery = perf.battery()
            thermal = thermalMonitor.read()
            delay(2000)
        }
    }

    // Animasi denyut juga memastikan jendela ini terus menggambar frame (agar FPS UI terukur).
    val transition = rememberInfiniteTransition(label = "pulse")
    val pulse by transition.animateFloat(
        initialValue = 0.25f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(700), RepeatMode.Reverse),
        label = "pulseAlpha"
    )

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { ScreenTitle("Performance Monitor", "Diperbarui setiap 2 detik") }
            Box(Modifier.size(12.dp).alpha(pulse).clip(CircleShape).background(AiszColors.Ok))
            Text("  LIVE", color = AiszColors.Ok, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }

        GlowCard {
            SectionTitle("FPS")
            StatRow("FPS game", "N/A", AiszColors.TextDim)
            Text(
                "Android tanpa root tidak menyediakan API resmi untuk membaca FPS aplikasi atau game lain, " +
                    "jadi angkanya tidak ditampilkan.",
                color = AiszColors.TextDim, fontSize = 12.sp
            )
            Spacer(Modifier.height(6.dp))
            StatRow("FPS render AISZ (jendela ini)", fpsMonitor.fps?.toString() ?: "mengukur...")
            StatRow("Refresh rate layar", String.format(Locale.US, "%.0f Hz", device.refreshRateHz))
        }

        GlowCard {
            SectionTitle("Temperatur")
            StatRow("Suhu baterai", formatCelsius(thermal.batteryC))
            StatRow("Indikator", thermal.level.label, levelColor(thermal.level))
            StatRow("Status termal sistem", thermal.thermalStatus ?: "N/A (butuh Android 10+)")
            Text(
                "Normal < 38 °C, Hangat 38–42 °C, Tinggi ≥ 42 °C (atau status termal sistem Sedang ke atas).",
                color = AiszColors.TextDim, fontSize = 11.sp
            )
        }

        GlowCard {
            SectionTitle("RAM")
            StatRow("Total", "${memory.totalMb} MB")
            StatRow("Tersedia", "${memory.availMb} MB")
            StatRow("Terpakai", "${memory.usedPercent}%")
            Spacer(Modifier.height(6.dp))
            LinearProgressIndicator(
                progress = { memory.usedPercent / 100f },
                modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                color = if (memory.usedPercent >= 90) AiszColors.Hot else AiszColors.Neon,
                trackColor = AiszColors.SurfaceHigh
            )
        }

        GlowCard {
            SectionTitle("Baterai")
            StatRow("Level", battery.levelPercent?.let { "$it%" } ?: "N/A")
            StatRow("Status", if (battery.charging) "Mengisi" else "Tidak mengisi")
            StatRow("Tegangan", battery.voltageMv?.let { "$it mV" } ?: "N/A")
        }

        GlowCard {
            SectionTitle("Perangkat")
            StatRow("Model", "${device.manufacturer} ${device.model}")
            StatRow("Android", "${device.androidVersion} (API ${device.apiLevel})")
            StatRow("Arsitektur", device.abi)
            StatRow("Core CPU", "${device.cpuCores}")
            StatRow("Layar", device.screen)
        }

        GlowCard {
            SectionTitle("Aplikasi berjalan")
            StatRow("Status", "N/A", AiszColors.TextDim)
            Text(
                "Android membatasi daftar aplikasi yang sedang berjalan tanpa izin khusus, " +
                    "sehingga bagian ini tidak ditampilkan.",
                color = AiszColors.TextDim, fontSize = 12.sp
            )
        }
    }
}

// =============================================================== SETTINGS

@Composable
fun SettingsScreen(activity: MainActivity) {
    val ctx = LocalContext.current
    val gs = remember { GameSettings(ctx) }
    val tick = activity.resumeTick.value

    var canWrite by remember(tick) { mutableStateOf(gs.canWriteSystemSettings()) }
    var overlayOk by remember(tick) { mutableStateOf(Settings.canDrawOverlays(ctx)) }
    var brightness by remember(tick) { mutableStateOf(gs.getBrightnessPercent().toFloat()) }
    var musicVol by remember { mutableStateOf(gs.getVolumePercent(AudioManager.STREAM_MUSIC).toFloat()) }
    var ringVol by remember { mutableStateOf(gs.getVolumePercent(AudioManager.STREAM_RING).toFloat()) }
    var profile by remember { mutableStateOf(gs.profile) }
    var orientation by remember { mutableStateOf(gs.orientation) }
    var keepOn by remember { mutableStateOf(gs.keepScreenOn) }

    val sliderColors = SliderDefaults.colors(
        thumbColor = AiszColors.Neon,
        activeTrackColor = AiszColors.Neon,
        inactiveTrackColor = AiszColors.SurfaceHigh
    )

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        ScreenTitle("Game Settings")

        GlowCard {
            SectionTitle("Profil gaming")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GamingProfile.values().forEach { p ->
                    NeonChip(p.label, profile == p) { profile = p }
                }
            }
            Spacer(Modifier.height(8.dp))
            Text(profile.description, color = AiszColors.TextDim, fontSize = 12.sp)
            Text(
                "Profil hanya mengatur kecerahan, volume media, dan layar tetap menyala. " +
                    "Profil tidak mengubah performa CPU/GPU maupun FPS.",
                color = AiszColors.TextDim, fontSize = 11.sp
            )
            Spacer(Modifier.height(10.dp))
            NeonButton("Terapkan profil", Modifier.fillMaxWidth()) {
                val r = gs.applyProfile(profile)
                keepOn = gs.keepScreenOn
                brightness = gs.getBrightnessPercent().toFloat()
                musicVol = gs.getVolumePercent(AudioManager.STREAM_MUSIC).toFloat()
                activity.applyWindowPrefs()
                val msg = buildString {
                    append("Profil ${profile.label} diterapkan. ")
                    if (!r.brightnessApplied) append("Kecerahan tidak diubah (izin Ubah pengaturan sistem belum diberikan). ")
                    if (!r.volumeApplied) append("Volume tidak dapat diubah.")
                }
                Toast.makeText(ctx, msg.trim(), Toast.LENGTH_LONG).show()
            }
        }

        GlowCard {
            SectionTitle("Kecerahan")
            if (!canWrite) {
                Text(
                    "Mengubah kecerahan sistem memerlukan izin \"Ubah pengaturan sistem\".",
                    color = AiszColors.Warn, fontSize = 12.sp
                )
                Spacer(Modifier.height(8.dp))
                GhostButton("Berikan izin") { ctx.safeStart(gs.writeSettingsIntent()) }
            } else {
                StatRow("Level", "${brightness.toInt()}%")
                Slider(
                    value = brightness,
                    onValueChange = { brightness = it },
                    onValueChangeFinished = { gs.setBrightnessPercent(brightness.toInt()) },
                    valueRange = 1f..100f,
                    colors = sliderColors
                )
            }
        }

        GlowCard {
            SectionTitle("Volume")
            StatRow("Media", "${musicVol.toInt()}%")
            Slider(
                value = musicVol,
                onValueChange = {
                    musicVol = it
                    gs.setVolumePercent(AudioManager.STREAM_MUSIC, it.toInt())
                },
                valueRange = 0f..100f,
                colors = sliderColors
            )
            StatRow("Dering", "${ringVol.toInt()}%")
            Slider(
                value = ringVol,
                onValueChange = {
                    ringVol = it
                    if (!gs.setVolumePercent(AudioManager.STREAM_RING, it.toInt())) {
                        Toast.makeText(ctx, "Volume dering tidak dapat diubah (mode Jangan Ganggu aktif?).", Toast.LENGTH_SHORT).show()
                    }
                },
                valueRange = 0f..100f,
                colors = sliderColors
            )
        }

        GlowCard {
            SectionTitle("Orientasi & layar")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OrientationMode.values().forEach { o ->
                    NeonChip(o.label, orientation == o) {
                        orientation = o
                        gs.orientation = o
                        activity.applyWindowPrefs()
                    }
                }
            }
            Text(
                "Orientasi berlaku untuk jendela AISZ GAME SPACE. Android tidak mengizinkan aplikasi memaksa orientasi game lain.",
                color = AiszColors.TextDim, fontSize = 11.sp,
                modifier = Modifier.padding(top = 8.dp)
            )
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Layar tetap menyala (di aplikasi ini)", color = AiszColors.Text, modifier = Modifier.weight(1f), fontSize = 14.sp)
                Switch(
                    checked = keepOn,
                    onCheckedChange = {
                        keepOn = it
                        gs.keepScreenOn = it
                        activity.applyWindowPrefs()
                    },
                    colors = SwitchDefaults.colors(
                        checkedTrackColor = AiszColors.Neon,
                        checkedThumbColor = AiszColors.Black,
                        uncheckedTrackColor = AiszColors.SurfaceHigh,
                        uncheckedThumbColor = AiszColors.TextDim
                    )
                )
            }
        }

        GlowCard {
            SectionTitle("Izin")
            StatRow("Tampil di atas aplikasi lain", if (overlayOk) "Diizinkan" else "Belum", if (overlayOk) AiszColors.Ok else AiszColors.Warn)
            StatRow("Ubah pengaturan sistem", if (canWrite) "Diizinkan" else "Belum", if (canWrite) AiszColors.Ok else AiszColors.Warn)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GhostButton("Izin overlay", Modifier.weight(1f)) {
                    ctx.safeStart(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}")))
                }
                GhostButton("Info aplikasi", Modifier.weight(1f)) {
                    ctx.safeStart(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}")))
                }
            }
            Text(
                "Di HyperOS/MIUI, jika panel tidak muncul, buka Info aplikasi > Izin lainnya dan aktifkan " +
                    "\"Tampilkan jendela pop-up saat berjalan di latar belakang\".",
                color = AiszColors.TextDim, fontSize = 11.sp,
                modifier = Modifier.padding(top = 8.dp)
            )
        }

        GlowCard {
            SectionTitle("Pintasan pengaturan sistem")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GameSettings.shortcuts.forEach { (title, action) ->
                    GhostButton(title, Modifier.weight(1f)) { ctx.safeStart(Intent(action)) }
                }
            }
        }
    }
}
