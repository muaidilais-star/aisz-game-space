# AISZ GAME SPACE

Aplikasi Android (Kotlin + Jetpack Compose) berisi dashboard, floating gaming panel,
game launcher, monitor FPS/suhu/RAM/baterai, touch tester, dan pengaturan gaming.
Tanpa root, tanpa exploit.

- Package: `com.aisz.gamespace`
- minSdk 24 (Android 7.0), targetSdk/compileSdk 35 (Android 15)
- AGP 8.6.1, Gradle 8.7, Kotlin 1.9.24, Compose BOM 2024.06.00, JDK 17

## Build APK debug

### Cara 1 - Android Studio
1. Buka folder ini lewat *File > Open*.
2. Tunggu Gradle sync selesai.
3. *Build > Build APK(s)*, atau jalankan `gradle assembleDebug` / `./gradlew assembleDebug`.
4. Hasil: `app/build/outputs/apk/debug/app-debug.apk`

### Cara 2 - GitHub Actions (tanpa instal apa pun)
Upload folder ini ke repositori GitHub. Workflow `.github/workflows/build-apk.yml`
membangun APK debug otomatis; unduh dari tab *Actions > Artifacts*.

### Cara 3 - Command line
Pasang JDK 17 + Android SDK 35, lalu: `gradle assembleDebug`
(`gradle wrapper --gradle-version 8.7` membuat `gradlew` jika diperlukan).

## Catatan perilaku
- FPS game selalu **N/A**: Android tanpa root tidak punya API resmi untuk FPS aplikasi lain.
  Yang diukur hanya FPS render jendela AISZ dan refresh rate layar.
- Suhu: suhu baterai + status termal sistem (Android 10+). Tidak ada data karangan.
- Kecerahan sistem butuh izin "Ubah pengaturan sistem"; panel butuh "Tampil di atas aplikasi lain".
- Di HyperOS: jika panel tidak muncul, aktifkan "Tampilkan jendela pop-up saat berjalan di latar belakang"
  di Info aplikasi > Izin lainnya.
- Profil gaming hanya mengatur kecerahan, volume media, dan layar tetap menyala.
